#!/bin/bash -v

echo "hn-start-app"
echo $*

# Stop the firewall to allow communication with the nodes
# TODO: find the exact ports to open
sudo systemctl stop firewalld


# Add librairies

if [ "$5" != "" ]
then
    echo Installing ROCKY
    mkdir -p /mnt/$2/installer
    mkdir -p /mnt/$2/install/Rocky/
    chmod 777 /mnt/$2/install/Rocky/
    chmod 777 /mnt/$2/installer
    cd /mnt/$2/installer
    wget $5 -O rocky.tbz2
    sudo tar -jxvf rocky.tbz2 -C /mnt/$2/install/Rocky/
fi

if [ "$4" != "" ]
then
    echo Downloading model
    mkdir /mnt/$2/work
    cd /mnt/$2/work
    wget -O - $4 | tar xvz
fi

if [ "$6" != "" ]
then
    mkdir ~/.Rocky/
    echo SERVER $6 ANY $7 > ~/.Rocky/license.lic
    echo USE_SERVER >> ~/.Rocky/license.lic
    echo license_id: FlexLM > ~/.Rocky/license_definition.txt
    echo license_path: /home/opc/.Rocky/license.lic >> ~/.Rocky/license_definition.txt
    echo version: 1 >> ~/.Rocky/license_definition.txt
fi
