#!/bin/bash -v

# Stop the firewall to allow communication with the nodes
# TODO: find the exact ports to open
echo "gpu-start-app"
echo $*

if [ "$1" != "" ]
then
    mkdir ~/.Rocky/
    echo SERVER $1 ANY $2 > ~/.Rocky/license.lic
    echo USE_SERVER >> ~/.Rocky/license.lic
    echo license_id: FlexLM > ~/.Rocky/license_definition.txt
    echo license_path: /home/opc/.Rocky/license.lic >> ~/.Rocky/license_definition.txt
    echo version: 1 >> ~/.Rocky/license_definition.txt
fi